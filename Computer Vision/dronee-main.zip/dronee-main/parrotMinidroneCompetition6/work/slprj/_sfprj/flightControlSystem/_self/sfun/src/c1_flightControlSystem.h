#ifndef __c1_flightControlSystem_h__
#define __c1_flightControlSystem_h__

/* Forward Declarations */
#ifndef c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG
#define c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG

typedef struct c1_tag_a7TcNrdk5JZcy5uxGijaRG c1_s_a7TcNrdk5JZcy5uxGijaRG;

#endif                                 /* c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG */

#ifndef c1_typedef_c1_cell_2
#define c1_typedef_c1_cell_2

typedef struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE c1_cell_2;

#endif                                 /* c1_typedef_c1_cell_2 */

#ifndef c1_typedef_c1_cell_wrap_1
#define c1_typedef_c1_cell_wrap_1

typedef struct c1_tag_L5JvjW1A13FyCQi5N783sB c1_cell_wrap_1;

#endif                                 /* c1_typedef_c1_cell_wrap_1 */

#ifndef c1_typedef_c1_cell_3
#define c1_typedef_c1_cell_3

typedef struct c1_tag_1Arln2w5g2jgtSu0nxxuyG c1_cell_3;

#endif                                 /* c1_typedef_c1_cell_3 */

#ifndef c1_typedef_c1_cell_0
#define c1_typedef_c1_cell_0

typedef struct c1_tag_aNmOBlUL9eIe9DuJb7zyUC c1_cell_0;

#endif                                 /* c1_typedef_c1_cell_0 */

#ifndef c1_typedef_c1_cell_4
#define c1_typedef_c1_cell_4

typedef struct c1_tag_9SoYFOHTFNVnYR44IKzdJH c1_cell_4;

#endif                                 /* c1_typedef_c1_cell_4 */

#ifndef c1_typedef_c1_cell_5
#define c1_typedef_c1_cell_5

typedef struct c1_tag_NN6thEF39FWL7a4zhq3UrE c1_cell_5;

#endif                                 /* c1_typedef_c1_cell_5 */

#ifndef c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD
#define c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD

typedef struct c1_tag_tP4ysjhyvuYk36JuHDg8bD c1_s_tP4ysjhyvuYk36JuHDg8bD;

#endif                                 /* c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD */

#ifndef c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF
#define c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF

typedef struct c1_tag_ynaaIE6q9xznGBkza31TCF c1_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF */

#ifndef c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD
#define c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD

typedef struct c1_tag_HOps0FrfA6RiWumqewPwZD c1_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD */

#ifndef c1_typedef_c1_s_QPZY2mznR0KV8lbnnjx9y
#define c1_typedef_c1_s_QPZY2mznR0KV8lbnnjx9y

typedef struct c1_tag_QPZY2mznR0KV8lbnnjx9y c1_s_QPZY2mznR0KV8lbnnjx9y;

#endif                                 /* c1_typedef_c1_s_QPZY2mznR0KV8lbnnjx9y */

#ifndef c1_typedef_c1_s_sL5r3tnOjefTceie37OHrH
#define c1_typedef_c1_s_sL5r3tnOjefTceie37OHrH

typedef struct c1_tag_sL5r3tnOjefTceie37OHrH c1_s_sL5r3tnOjefTceie37OHrH;

#endif                                 /* c1_typedef_c1_s_sL5r3tnOjefTceie37OHrH */

#ifndef c1_typedef_c1_s_fnNBZRcViWKJIkyfK13VxD
#define c1_typedef_c1_s_fnNBZRcViWKJIkyfK13VxD

typedef struct c1_tag_fnNBZRcViWKJIkyfK13VxD c1_s_fnNBZRcViWKJIkyfK13VxD;

#endif                                 /* c1_typedef_c1_s_fnNBZRcViWKJIkyfK13VxD */

#ifndef c1_typedef_c1_s_IPBrlHl0TINQKXLbyKcqRF
#define c1_typedef_c1_s_IPBrlHl0TINQKXLbyKcqRF

typedef struct c1_tag_IPBrlHl0TINQKXLbyKcqRF c1_s_IPBrlHl0TINQKXLbyKcqRF;

#endif                                 /* c1_typedef_c1_s_IPBrlHl0TINQKXLbyKcqRF */

/* Type Definitions */
#ifndef c1_struct_c1_tag_a7TcNrdk5JZcy5uxGijaRG
#define c1_struct_c1_tag_a7TcNrdk5JZcy5uxGijaRG

struct c1_tag_a7TcNrdk5JZcy5uxGijaRG
{
  char_T f1[7];
  char_T f2[7];
};

#endif                                 /* c1_struct_c1_tag_a7TcNrdk5JZcy5uxGijaRG */

#ifndef c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG
#define c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG

typedef struct c1_tag_a7TcNrdk5JZcy5uxGijaRG c1_s_a7TcNrdk5JZcy5uxGijaRG;

#endif                                 /* c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG */

#ifndef c1_struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE
#define c1_struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE

struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE
{
  char_T f1[4];
  char_T f2[9];
  char_T f3[2];
};

#endif                                 /* c1_struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE */

#ifndef c1_typedef_c1_cell_2
#define c1_typedef_c1_cell_2

typedef struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE c1_cell_2;

#endif                                 /* c1_typedef_c1_cell_2 */

#ifndef c1_struct_c1_tag_L5JvjW1A13FyCQi5N783sB
#define c1_struct_c1_tag_L5JvjW1A13FyCQi5N783sB

struct c1_tag_L5JvjW1A13FyCQi5N783sB
{
  char_T f1[7];
};

#endif                                 /* c1_struct_c1_tag_L5JvjW1A13FyCQi5N783sB */

#ifndef c1_typedef_c1_cell_wrap_1
#define c1_typedef_c1_cell_wrap_1

typedef struct c1_tag_L5JvjW1A13FyCQi5N783sB c1_cell_wrap_1;

#endif                                 /* c1_typedef_c1_cell_wrap_1 */

#ifndef c1_struct_c1_tag_1Arln2w5g2jgtSu0nxxuyG
#define c1_struct_c1_tag_1Arln2w5g2jgtSu0nxxuyG

struct c1_tag_1Arln2w5g2jgtSu0nxxuyG
{
  char_T f1[4];
  char_T f2[8];
  char_T f3[6];
};

#endif                                 /* c1_struct_c1_tag_1Arln2w5g2jgtSu0nxxuyG */

#ifndef c1_typedef_c1_cell_3
#define c1_typedef_c1_cell_3

typedef struct c1_tag_1Arln2w5g2jgtSu0nxxuyG c1_cell_3;

#endif                                 /* c1_typedef_c1_cell_3 */

#ifndef c1_struct_c1_tag_aNmOBlUL9eIe9DuJb7zyUC
#define c1_struct_c1_tag_aNmOBlUL9eIe9DuJb7zyUC

struct c1_tag_aNmOBlUL9eIe9DuJb7zyUC
{
  char_T f1[6];
  char_T f2[12];
  char_T f3[6];
  char_T f4[5];
  char_T f5[5];
  char_T f6[4];
  char_T f7[6];
  char_T f8[9];
  char_T f9[5];
  char_T f10[6];
  char_T f11[4];
  char_T f12[6];
  char_T f13[8];
  char_T f14[6];
  char_T f15[6];
  char_T f16[4];
  char_T f17[6];
  char_T f18[6];
  char_T f19[8];
  char_T f20[4];
  char_T f21[7];
  char_T f22[4];
  char_T f23[6];
};

#endif                                 /* c1_struct_c1_tag_aNmOBlUL9eIe9DuJb7zyUC */

#ifndef c1_typedef_c1_cell_0
#define c1_typedef_c1_cell_0

typedef struct c1_tag_aNmOBlUL9eIe9DuJb7zyUC c1_cell_0;

#endif                                 /* c1_typedef_c1_cell_0 */

#ifndef c1_struct_c1_tag_9SoYFOHTFNVnYR44IKzdJH
#define c1_struct_c1_tag_9SoYFOHTFNVnYR44IKzdJH

struct c1_tag_9SoYFOHTFNVnYR44IKzdJH
{
  char_T f1[2];
  char_T f2[9];
  char_T f3[4];
};

#endif                                 /* c1_struct_c1_tag_9SoYFOHTFNVnYR44IKzdJH */

#ifndef c1_typedef_c1_cell_4
#define c1_typedef_c1_cell_4

typedef struct c1_tag_9SoYFOHTFNVnYR44IKzdJH c1_cell_4;

#endif                                 /* c1_typedef_c1_cell_4 */

#ifndef c1_struct_c1_tag_NN6thEF39FWL7a4zhq3UrE
#define c1_struct_c1_tag_NN6thEF39FWL7a4zhq3UrE

struct c1_tag_NN6thEF39FWL7a4zhq3UrE
{
  char_T f1[6];
  char_T f2[9];
  char_T f3[4];
};

#endif                                 /* c1_struct_c1_tag_NN6thEF39FWL7a4zhq3UrE */

#ifndef c1_typedef_c1_cell_5
#define c1_typedef_c1_cell_5

typedef struct c1_tag_NN6thEF39FWL7a4zhq3UrE c1_cell_5;

#endif                                 /* c1_typedef_c1_cell_5 */

#ifndef c1_struct_c1_tag_tP4ysjhyvuYk36JuHDg8bD
#define c1_struct_c1_tag_tP4ysjhyvuYk36JuHDg8bD

struct c1_tag_tP4ysjhyvuYk36JuHDg8bD
{
  c1_s_a7TcNrdk5JZcy5uxGijaRG _data;
};

#endif                                 /* c1_struct_c1_tag_tP4ysjhyvuYk36JuHDg8bD */

#ifndef c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD
#define c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD

typedef struct c1_tag_tP4ysjhyvuYk36JuHDg8bD c1_s_tP4ysjhyvuYk36JuHDg8bD;

#endif                                 /* c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD */

#ifndef c1_struct_c1_tag_ynaaIE6q9xznGBkza31TCF
#define c1_struct_c1_tag_ynaaIE6q9xznGBkza31TCF

struct c1_tag_ynaaIE6q9xznGBkza31TCF
{
  c1_cell_2 _data;
};

#endif                                 /* c1_struct_c1_tag_ynaaIE6q9xznGBkza31TCF */

#ifndef c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF
#define c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF

typedef struct c1_tag_ynaaIE6q9xznGBkza31TCF c1_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF */

#ifndef c1_struct_c1_tag_HOps0FrfA6RiWumqewPwZD
#define c1_struct_c1_tag_HOps0FrfA6RiWumqewPwZD

struct c1_tag_HOps0FrfA6RiWumqewPwZD
{
  c1_cell_wrap_1 _data;
};

#endif                                 /* c1_struct_c1_tag_HOps0FrfA6RiWumqewPwZD */

#ifndef c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD
#define c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD

typedef struct c1_tag_HOps0FrfA6RiWumqewPwZD c1_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD */

#ifndef c1_struct_c1_tag_QPZY2mznR0KV8lbnnjx9y
#define c1_struct_c1_tag_QPZY2mznR0KV8lbnnjx9y

struct c1_tag_QPZY2mznR0KV8lbnnjx9y
{
  c1_cell_3 _data;
};

#endif                                 /* c1_struct_c1_tag_QPZY2mznR0KV8lbnnjx9y */

#ifndef c1_typedef_c1_s_QPZY2mznR0KV8lbnnjx9y
#define c1_typedef_c1_s_QPZY2mznR0KV8lbnnjx9y

typedef struct c1_tag_QPZY2mznR0KV8lbnnjx9y c1_s_QPZY2mznR0KV8lbnnjx9y;

#endif                                 /* c1_typedef_c1_s_QPZY2mznR0KV8lbnnjx9y */

#ifndef c1_struct_c1_tag_sL5r3tnOjefTceie37OHrH
#define c1_struct_c1_tag_sL5r3tnOjefTceie37OHrH

struct c1_tag_sL5r3tnOjefTceie37OHrH
{
  c1_cell_0 _data;
};

#endif                                 /* c1_struct_c1_tag_sL5r3tnOjefTceie37OHrH */

#ifndef c1_typedef_c1_s_sL5r3tnOjefTceie37OHrH
#define c1_typedef_c1_s_sL5r3tnOjefTceie37OHrH

typedef struct c1_tag_sL5r3tnOjefTceie37OHrH c1_s_sL5r3tnOjefTceie37OHrH;

#endif                                 /* c1_typedef_c1_s_sL5r3tnOjefTceie37OHrH */

#ifndef c1_struct_c1_tag_fnNBZRcViWKJIkyfK13VxD
#define c1_struct_c1_tag_fnNBZRcViWKJIkyfK13VxD

struct c1_tag_fnNBZRcViWKJIkyfK13VxD
{
  c1_cell_4 _data;
};

#endif                                 /* c1_struct_c1_tag_fnNBZRcViWKJIkyfK13VxD */

#ifndef c1_typedef_c1_s_fnNBZRcViWKJIkyfK13VxD
#define c1_typedef_c1_s_fnNBZRcViWKJIkyfK13VxD

typedef struct c1_tag_fnNBZRcViWKJIkyfK13VxD c1_s_fnNBZRcViWKJIkyfK13VxD;

#endif                                 /* c1_typedef_c1_s_fnNBZRcViWKJIkyfK13VxD */

#ifndef c1_struct_c1_tag_IPBrlHl0TINQKXLbyKcqRF
#define c1_struct_c1_tag_IPBrlHl0TINQKXLbyKcqRF

struct c1_tag_IPBrlHl0TINQKXLbyKcqRF
{
  c1_cell_5 _data;
};

#endif                                 /* c1_struct_c1_tag_IPBrlHl0TINQKXLbyKcqRF */

#ifndef c1_typedef_c1_s_IPBrlHl0TINQKXLbyKcqRF
#define c1_typedef_c1_s_IPBrlHl0TINQKXLbyKcqRF

typedef struct c1_tag_IPBrlHl0TINQKXLbyKcqRF c1_s_IPBrlHl0TINQKXLbyKcqRF;

#endif                                 /* c1_typedef_c1_s_IPBrlHl0TINQKXLbyKcqRF */

#ifndef typedef_SFc1_flightControlSystemInstanceStruct
#define typedef_SFc1_flightControlSystemInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  int32_T c1_sfEvent;
  boolean_T c1_doneDoubleBufferReInit;
  void *c1_RuntimeVar;
  int32_T c1_IsDebuggerActive;
  int32_T c1_IsSequenceViewerPresent;
  int32_T c1_SequenceViewerOptimization;
  int32_T c1_IsHeatMapPresent;
  uint8_T c1_JITStateAnimation[1];
  uint8_T c1_JITTransitionAnimation[1];
  uint32_T c1_mlFcnLineNumber;
  void *c1_fcnDataPtrs[2];
  const char_T *c1_dataNames[2];
  uint32_T c1_numFcnVars;
  uint32_T c1_ssIds[2];
  uint32_T c1_statuses[2];
  void *c1_outMexFcns[2];
  void *c1_inMexFcns[2];
  CovrtStateflowInstance *c1_covrtInstance;
  void *c1_fEmlrtCtx;
  boolean_T (*c1_BW)[19200];
  boolean_T (*c1_skel)[19200];
} SFc1_flightControlSystemInstanceStruct;

#endif                                 /* typedef_SFc1_flightControlSystemInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c1_flightControlSystem_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c1_flightControlSystem_get_check_sum(mxArray *plhs[]);
extern void c1_flightControlSystem_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
